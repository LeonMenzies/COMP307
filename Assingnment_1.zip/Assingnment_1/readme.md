## Instructions

### Part 1.
Run the program as a python script with two inputs
e.g. python3 part1.py "wine-training" "wine-test" 
1: The training file name
2: The test file name

### Part 2.
Run the program as a python script with two inputs
e.g. python3 part2.py "hepatitis-training" "hepatitis-test" 
1: The training file name
2: The test file name

### Part 3.
Run the program as a python script with one input 
e.g. python3 part3.py "ionosphere.data"
1: The training file name